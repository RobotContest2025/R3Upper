#include "Action.h"
#include "Odrive.h"
#include "RobStride2.h"
#include "tim.h"
#include <math.h>

extern TIM_HandleTypeDef htim1;
extern QueueHandle_t action_queue;
extern QueueHandle_t copilot_action_queue;
extern QueueHandle_t action_semaphore;

extern float chassis_v;

extern Motor2006Ex_t claw_motor;
extern Motor3508Ex_t push_motor;
extern ODrive jump_motor1;
extern ODrive jump_motor2;
extern RobStride_t throw_motor;

extern uint8_t throw_motor_vel_mode;
extern uint8_t jump_motor_vel_mode;
extern uint8_t jump_motor_enable;
extern int32_t claw_motor_target_pos;
extern float throw_motor_target_vel;
extern float throw_motor_target_torque;
extern float jump_motor_target_vel;
extern float jump_motor_target_cur;
extern float lift_motor1_target_vel;
extern float lift_motor2_target_vel;


float lv53_gate_dis = 270.0f;
float debug_value = 0.0f;
int32_t launch_velocity = -60.0f;
int32_t start_launch_time = 1100;


extern float pos_offset;
void ResetAction(void* param)	//上电时执行一次的动作，将机械结构件复位到正确的位置
{
	UNUSED(param);
	float reset_offset=0.0f;
	float vel_record[8]={1.0f};
	int record_point=0;
	float sum=0.0f;
	
	jump_motor_vel_mode=1;
	jump_motor_target_vel=1.0f;
	vTaskDelay(2000);
	do
	{
		vTaskDelay(50);
		vel_record[record_point]=jump_motor1.posVelEstimateGet.velocity;
		record_point=(record_point+1)%16;
		sum=0.0f;
		for(int i=0;i<16;i++)
			sum+=ABS(vel_record[i]);
		sum=sum/8.0f;
	}while(sum>0.01f);
	pos_offset=jump_motor1.posVelEstimateGet.position;
	jump_motor_vel_mode=0;
	jump_motor_target_vel=0.0f;
	ActionFinished();
}

float unlock_rad1=4.10f;
float lock_rad1=3.54f;
float unlock_rad2=3.56f;
float lock_rad2=3.0f;
void TestAction(void *param)		//解锁锁定
{
	UNUSED(param);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, SetSteeringEngineRAD270(unlock_rad1));
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, SetSteeringEngineRAD270(unlock_rad2));
	ActionFinished();
}

float throw_height=5.0f;
float throw_start_rad=0.0f;
float throw_break_torque=-30.0f;
float throw_target_omega=3.0f;
float throw_detach_rad=2.8f;
float throw_break_rad=3.14f;
float claw_touch_pos=0.0f;
int32_t claw_detach_pos=110000;
float omega_increase_stop_rad=1.57f;	//在转动1/4圈时间内加速
float omega_increase_cal_stop_rad=1.40f;	//提前停止迭代计算防止因为分母过小造成输出力矩震荡
float claw_detach_time=0.1f;		//夹爪张开耗时

void ReadyThrowAction(void* param)
{
	claw_motor_target_pos=claw_touch_pos;
	
	if(jump_motor1.posVelEstimateGet.position<throw_height)			//调整抛射高度
	{
		jump_motor_target_vel=0.5f;
		while(jump_motor1.posVelEstimateGet.position<throw_height)
			vTaskDelay(3);
	}
	else if(jump_motor1.posVelEstimateGet.position>throw_height)
	{
		jump_motor_target_vel=-0.5f;
		while(jump_motor1.posVelEstimateGet.position>throw_height)
			vTaskDelay(3);
	}
	jump_motor_target_vel=0.0f;

	throw_motor_vel_mode=1;
	if(throw_motor.state.rad>throw_start_rad)			//调整抛射大臂角度
	{
		throw_motor_target_vel=-0.5f;
		while(throw_motor.state.rad>throw_start_rad)
			vTaskDelay(3);
	}
	else if(throw_motor.state.rad<throw_start_rad)
	{
		throw_motor_target_vel=0.5f;
		while(throw_motor.state.rad<throw_start_rad)
			vTaskDelay(3);
	}
	throw_motor_target_vel=0.0f;

	ActionFinished();
}

void ThrowAction(void* param)
{
	UNUSED(param);
	throw_motor_vel_mode=1;
	throw_motor_target_torque=0.0f;
	throw_motor_target_vel=0.0f;
	float aerfa,d_omega;
	float filter_k=0.8f;
	float aerfa_filter=0.5f*(throw_target_omega*throw_target_omega/(omega_increase_stop_rad-throw_motor.state.rad));
	while(throw_motor.state.rad<omega_increase_cal_stop_rad)
	{
		aerfa=0.5f*((throw_target_omega*throw_target_omega-throw_motor.state.omega*throw_motor.state.omega)/(omega_increase_stop_rad-throw_motor.state.rad));
		d_omega=aerfa*0.002f;     //加速度*迭代时间为每次迭代二点速度改变量
		aerfa_filter=filter_k*aerfa_filter+(1.0f-filter_k)*aerfa;
		throw_motor_target_vel=throw_motor_target_vel+d_omega;		//期望速度线性增加
		throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,aerfa,1);		//力矩前馈项计算
		vTaskDelay(2);
	}

	while(throw_motor.state.rad<omega_increase_stop_rad)	//终止计算加速段，使用之前计算的滤波后的加速度作为力矩前馈计算的数据来源
	{
		throw_motor_target_vel=throw_motor_target_vel+aerfa_filter*0.002f;	//计算本次迭代的目标速度
		throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,aerfa_filter,1);
		vTaskDelay(2);
	}
	
	//加速段完成，使用PID保持匀速和力矩前馈项
	throw_motor_target_vel=throw_target_omega;
	uint8_t has_ball=1;
	while(throw_motor.state.rad<throw_break_rad)	//匀速段
	{
		if(throw_motor.state.rad>throw_detach_rad)	//大于抛球点后，蓝球负载消失
			has_ball=0;
		if(throw_target_omega*claw_detach_time>(throw_detach_rad-throw_motor.state.rad))	//提前预估时间释放球
			claw_motor_target_pos=claw_detach_pos;
		
		throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,0.0f,has_ball);
		vTaskDelay(3);
	}

	throw_motor_vel_mode=0;
	throw_motor_target_torque=throw_break_torque;
	while(throw_motor.state.omega>0.0f)			//等待刹车完成
		vTaskDelay(3);

	throw_motor_target_torque=0.0f;
	throw_motor_target_vel=0.0f;
	throw_motor_vel_mode=1;
	vTaskDelay(1000);

	throw_motor_target_vel=-1.0f;					//大臂复位
	claw_motor_target_pos=claw_touch_pos;
	while(throw_motor.state.rad>throw_start_rad)
		vTaskDelay(3);
	throw_motor_target_vel=0.0f;
	throw_motor_vel_mode=0;
	ActionFinished();
}

uint8_t claw_next_step=1;
void DetachClawTask(void* param)
{
	claw_next_step=1;
	claw_motor_target_pos=claw_detach_pos;
	while(claw_next_step)
		vTaskDelay(100);
	claw_motor_target_pos=0;
	ActionFinished();
}

float k_x_r=8.0f/0.86f;
float dribble_start_pos=-1.0f;
float dribble_stop_pos=-4.5934f;
float pos_offset=0.0f;

void ReadyDribbleAction(void* param)
{
	jump_motor_vel_mode=1;
	if(jump_motor1.posVelEstimateGet.position-pos_offset<dribble_start_pos)			//调整大臂高度
	{
		jump_motor_target_vel=0.5f;
		while(jump_motor1.posVelEstimateGet.position-pos_offset<dribble_start_pos)
			vTaskDelay(5);
	}
	else if(jump_motor1.posVelEstimateGet.position-pos_offset>dribble_start_pos)
	{
		jump_motor_target_vel=-0.5f;
		while(jump_motor1.posVelEstimateGet.position-pos_offset>dribble_start_pos)
			vTaskDelay(5);
	}
	jump_motor_target_vel=0.0f;

	throw_motor_vel_mode=1;
	if(throw_motor.state.rad>1.5707963f)			//调整抛射大臂角度
	{
		throw_motor_target_vel=-0.5f;
		while(throw_motor.state.rad>1.5707963f)
		{
			throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,0.0f,1);
			vTaskDelay(3);
		}
	}
	else if(throw_motor.state.rad<1.5707963f)
	{
		throw_motor_target_vel=0.5f;
		while(throw_motor.state.rad<1.5707963f)
		{
			throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,0.0f,1);
			vTaskDelay(3);
		}
			
	}
	throw_motor_target_vel=0.0f;
	ActionFinished();
}

const float g=9.802;
const float dirbble_height=0.702;
float arm_length=0.6f;
float Ek_consume_rate=0.72f;				//实验测量篮球掉到地上后的能量剩余比例
float K_p=0.35f;
float dribble_move_cur=-1.0f;
float dribble_break_cur=1.0f;
uint8_t dribble_next_step;

void DribbingBallAction(void* param)
{
	UNUSED(param);
	jump_motor_vel_mode=0;
	claw_motor_target_pos=claw_detach_pos;
	vTaskDelay(100);
	jump_motor_target_cur=dribble_move_cur;
	while(jump_motor1.posVelEstimateGet.position-pos_offset>dribble_stop_pos)
		vTaskDelay(3);
	
	jump_motor_vel_mode=1;
	jump_motor_target_cur=dribble_break_cur;
	jump_motor_target_vel=0.0f;
	dribble_next_step=1;
	while(jump_motor1.posVelEstimateGet.velocity<0.0f)
		vTaskDelay(3);
	jump_motor_target_cur=0.0f;
	while(dribble_next_step)
		vTaskDelay(3);
	claw_motor_target_pos=0;
	ActionFinished();
}


float friction_compen=0.3f;
float arm_torque_compen_90=4.06031561f;
float arm_inertia=0.288f;

float ball_torque_compen_90=6.50327778f-4.06031561f;
float ball_inertia=0.269f;
float GravityTorqueCompensation(float rad,float omega,float aerfa,uint8_t has_ball)
{
	UNUSED(rad);
	float torque_feedforward=0.0f;

	if(omega>0.05f)	//摩擦力补偿
		torque_feedforward=friction_compen;
	else if(omega<-0.05f)
		torque_feedforward=-friction_compen;

	if(has_ball)		//重力补偿
		torque_feedforward=torque_feedforward+ball_torque_compen_90*sin(rad);
	torque_feedforward=torque_feedforward+arm_torque_compen_90*sin(rad);

	if(has_ball)		//转矩补偿
		torque_feedforward=torque_feedforward+aerfa*ball_inertia;
	torque_feedforward=torque_feedforward+aerfa*arm_inertia;

	return torque_feedforward;
}

uint8_t next_measure=1;
uint32_t dt_ms;
void MeasureTask(void* param)
{
	next_measure=1;
	while(next_measure)
		vTaskDelay(200);
	next_measure=1;

	throw_motor_vel_mode=1;
	throw_motor_target_torque=0.0f;
	if(throw_motor.state.rad>1.570796325f)			//调整抛射大臂角度到90度
	{
		throw_motor_target_vel=-0.1f;
		while(throw_motor.state.rad>1.570796325f)
			vTaskDelay(3);
	}
	else if(throw_motor.state.rad<1.570796325f)
	{
		throw_motor_target_vel=0.1f;
		while(throw_motor.state.rad<1.570796325f)
			vTaskDelay(3);
	}
	throw_motor_target_vel=0.0f;

	while(next_measure)
		vTaskDelay(200);
	next_measure=1;

	throw_motor_vel_mode=0;
	throw_motor_target_vel=0;
	while(next_measure)		  //验证重力和摩擦力补偿的成果
	{
		throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,0.0f,0);
		vTaskDelay(3);
	}
	next_measure=1;
	dt_ms=HAL_GetTick();
	while(throw_motor.state.rad<3.14159265f)
	{
		throw_motor_target_torque=GravityTorqueCompensation(throw_motor.state.rad,throw_motor.state.omega,0.0f,0)+1.0f;
		vTaskDelay(3);
	}
	dt_ms=HAL_GetTick()-dt_ms;
	throw_motor_target_torque=0.0f;
	throw_motor_vel_mode=1;
	throw_motor_target_vel=0.0f;
	ActionFinished();
}

/*int32_t NextClawState()
{
	static uint8_t last_state;
}*/

uint16_t SetSteeringEngineRAD180(float rad)
{
	const uint16_t base = 500;
	const float k = 1900 / PI;
	if (rad > PI)
		rad = PI;
	else if (rad < 0.0f)
		rad = 0.0f;
	return base + (uint16_t)(rad * k);
}

uint16_t SetSteeringEngineRAD270(float rad)
{
	const uint16_t base = 500;
	const float k = 1900 / (1.5*PI);
	if (rad > PI*1.5)
		rad = PI*1.5;
	else if (rad < 0.0f)
		rad = 0.0f;
	return base + (uint16_t)(rad * k);
}

void MotorTargetTrack(int target, int *ctrl_var, int rate)
{
	while (*ctrl_var!=target) // 复位到0
	{
		if (*ctrl_var > target+rate * TARGET_TRACK_UPDATE_TIME)
			*ctrl_var = *ctrl_var - rate * TARGET_TRACK_UPDATE_TIME;
		else if(*ctrl_var < target-rate * TARGET_TRACK_UPDATE_TIME)
			*ctrl_var = *ctrl_var + rate * TARGET_TRACK_UPDATE_TIME;
		else
			*ctrl_var=target;
		vTaskDelay(pdMS_TO_TICKS(TARGET_TRACK_UPDATE_TIME));
	}
}

void MotorTargetTrack_float(float target, float *ctrl_var, float rate)
{
	while (*ctrl_var!=target) // 复位到0
	{
		if (*ctrl_var > target+rate * TARGET_TRACK_UPDATE_TIME)
			*ctrl_var = *ctrl_var - rate * TARGET_TRACK_UPDATE_TIME;
		else if(*ctrl_var < target-rate * TARGET_TRACK_UPDATE_TIME)
			*ctrl_var = *ctrl_var + rate * TARGET_TRACK_UPDATE_TIME;
		else
			*ctrl_var=target;
		vTaskDelay(pdMS_TO_TICKS(TARGET_TRACK_UPDATE_TIME));
	}
}
